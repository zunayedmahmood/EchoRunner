#!/usr/bin/env bash
set -euo pipefail
./build/dev-debug/sound-maze --level levels/level_01_training_loop.json --trainer --cue-density rich --telemetry "$@"

# Asset Library

Original placeholder art for Sound Maze: Echo Runner.

- Use PNG files directly in the game.
- Keep SVG files as editable source assets.
- Use `manifest.json` as the loading contract.
- Replace assets later with professional art while keeping IDs stable.
- The visual layer supports low-vision/trainer use only; sound remains the primary gameplay interface.

# 03 - Game Core, Simulation, Movement, and Level Design

> Grounding: This package is built from the supplied Sound-Maze design plan, HCI study toolkit guide, and OpenAL Programmer's Guide. It keeps the project original: no copied Pac-Man art, sounds, level layouts, branding, or character names.

## Goal

Build a deterministic maze-chase simulation where visual rendering is optional. The game core must work headlessly because replay, testing, and accessibility validation depend on exact state transitions.

## Core objects

| Object | Purpose |
|---|---|
| `Level` | static grid, tile metadata, landmarks, spawn points |
| `RunState` | active run time, score, lives, mode, RNG seed |
| `Player` | position, direction, queued direction, movement progress |
| `Enemy` | position, state, target, personality, warning signature |
| `Collectible` | pellet, power item, fruit/bonus |
| `CueRequest` | semantic request created by the game core for the accessibility runtime |

## Tile grammar

Use meaningful tiles, not decorative pixels.

| Code | Type | Gameplay meaning | Audio meaning |
|---|---|---|---|
| `#` | Wall | blocks movement | wall knock on invalid move |
| `.` | Pellet | reward/progress | soft tick when collected |
| `_` | Corridor | movement path | step rhythm or silence |
| `J` | Junction | decision point | directional open-exit chime / scan summary |
| `P` | Power | temporary reversal | hum nearby, activation, countdown |
| `F` | Fruit | bonus lure | directional melodic lure |
| `E` | EnemyGate | enemy home | low machine landmark |
| `S` | Start | spawn | start tone, orientation cue |
| `A` | SafePocket | recovery | calm wind landmark |
| `W` | Warp | shortcut | whoosh and exit ping |

## Level file format

Use JSON for MVP. Later you can add Tiled `.tmx` import.

```json
{
  "id": "level_01_training_loop",
  "name": "Training Loop",
  "version": 1,
  "seed_policy": "fixed_for_tests",
  "grid": [
    "#############",
    "#S..J...P..#",
    "#.#.###.#..#",
    "#F..J..E...#",
    "#############"
  ],
  "player_spawn": [1,1],
  "enemy_spawns": [{"id":"hunter_01", "tile":[7,3], "archetype":"hunter"}],
  "landmarks": [
    {"id":"safe_loop", "tiles":[[1,1],[2,1],[3,1]], "sound":"landmark_safe_loop"},
    {"id":"enemy_gate", "tiles":[[7,3]], "sound":"landmark_enemy_gate"}
  ],
  "difficulty": {
    "player_tiles_per_sec": 4.0,
    "enemy_tiles_per_sec": 2.6,
    "turn_buffer_ms": 500,
    "cue_density": "rich"
  }
}
```

## Fixed simulation loop

```cpp
constexpr double kTick = 1.0 / 60.0;
double accumulator = 0;

while (running) {
    double frameTime = clock.elapsed();
    accumulator += frameTime;
    pollInput();
    while (accumulator >= kTick) {
        game.update(kTick);
        accessibilityRuntime.observe(game.snapshot());
        telemetry.recordTick(game.snapshot());
        accumulator -= kTick;
    }
    renderTrainer(game.snapshot());
}
```

## Movement rules

### Direction queue

Blind-first movement must forgive early turns.

- Keep the last direction intent for `250-500 ms`.
- Execute it at the next tile center or valid junction.
- If invalid, play wall rejection and keep moving if current direction is valid.
- In beginner mode, expand turn window and auto-center player in corridor.

### Collision

```text
if next tile is wall:
    if current direction would hit wall:
        stop at tile center
        emit cue: wall_knock
    if queued direction invalid:
        emit cue: invalid_turn
else:
    continue moving
```

### Junction detection

A tile is a junction when it has 3+ open exits, or when level metadata marks it as `J`.

On entering a junction:

- generate `junction_arrived` event;
- update scan summary;
- in tutorial/rich mode, play open-exit chime;
- in expert mode, keep only critical direction feedback.

## Scoring model

| Event | Score | Notes |
|---|---:|---|
| Pellet collected | 10 | small reward |
| Fruit collected | 100-500 | level-specific lure |
| Power item collected | 50 | mode shift |
| Enemy caught in power mode | 200, then combo multiplier | never required to clear |
| Level clear | time/risk bonus | optional |

## Power mode

```text
inactive -> activation -> active_chase -> warning_flash -> expired -> inactive
```

Power mode requirements:

- Enemies change state to frightened.
- Enemy cue timbre changes.
- Countdown begins before expiration.
- Expiration never happens silently.
- Telemetry records activation, countdown, and expiration.

## Level progression plan

| Level | Lesson | New variable | Constraint |
|---|---|---|---|
| 1 Training Loop | movement, walls, junctions | none | one slow enemy or no enemy in first module |
| 2 Crossroads | route choice | fruit lure | no dead ends until taught |
| 3 Power Route | power reversal | power countdown | one hunter only |
| 4 Double Loop | escape planning | second loop | enemy speed still moderate |
| 5 Enemy Mix | enemy personalities | two enemies | no reduced cues yet |
| 6 Timed Bonus | planning under pressure | timed fruit | standard cue density |
| 7 Expert Silence | mastery | reduced cues | only after optional tutorial |

## Level authoring workflow

1. Sketch paper map.
2. Tag every tile with gameplay meaning.
3. Add landmarks by zone, not by tile spam.
4. Run headless path validation.
5. Run bot clearability test.
6. Run audio-only preview.
7. Run sighted screen-off internal test.
8. Run blind/low-vision playtest.
9. Lock the level version and save golden replay.

## Fairness checks

A level is rejected if:

- death can occur without a prior threat cue;
- a dead end has no taught warning;
- a junction cannot be understood by scan or audio cues;
- a power state expires silently;
- enemy route pressure relies on visual reaction timing;
- cue overlap hides critical danger.

## Headless unit tests

```text
TestPlayerStopsAtWall
TestQueuedTurnExecutesAtNextJunction
TestInvalidQueuedTurnKeepsCurrentDirection
TestPelletCollectedOnce
TestPowerModeTransitionsWithCountdown
TestLevelClearRequiresAllPellets
TestReplayDeterminismSameSeed
TestJunctionSummaryMatchesOpenDirections
```

## Acceptance gate

Run:

```bash
sound-maze --headless --level levels/level_01_training_loop.json --script tests/scripts/clear_level_01.inputs --write-replay exports/replay_logs/level_01.json
sound-maze-tools replay-verify exports/replay_logs/level_01.json --expect cleared=true --expect deaths=0
```

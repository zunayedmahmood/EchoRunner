# 04 - Input, Accessibility Runtime, Menus, and Tutorial

> Grounding: This package is built from the supplied Sound-Maze design plan, HCI study toolkit guide, and OpenAL Programmer's Guide. It keeps the project original: no copied Pac-Man art, sounds, level layouts, branding, or character names.

## Goal

Create a complete no-mouse interaction model. The player must be able to start, learn, play, pause, change settings, and exit with keyboard only.

## Input actions

Do not bind gameplay directly to physical keys. Bind physical keys to semantic actions.

```cpp
enum class Action {
    MoveUp, MoveDown, MoveLeft, MoveRight,
    Scan, RepeatLastCue, Confirm, Back, Pause,
    PanicReorient, MarkConfusion, ToggleTrainerAssist
};
```

## Default input modes

| Mode | Keys | Target |
|---|---|---|
| Arrow mode | arrows, Space scan, R repeat, Esc pause | general users |
| WASD mode | W/A/S/D, Q scan, E confirm, R repeat | PC gamers |
| Six-key mode A | S left, D up, F right, J down, K scan/repeat, L back/pause | compact tactile keyboard |
| Six-key mode B | S left, D up, F right, J scan, K confirm/repeat, L back; down as D+K chord | experimental one-hand mode |
| Trainer mode | F1 help, 1-9 overlays, T toggle cue panel | trainer only |

Start with Six-key mode A because it has a dedicated down key and lower cognitive load. Keep chord mode for experiments.

## Input buffering

| Action | Buffer behavior |
|---|---|
| Movement | queue for 250-500 ms or until next junction |
| Scan | immediate; may be rate-limited |
| Repeat | repeats last non-critical cue summary |
| Panic | training mode: slow time for 2s and speak safe summary |
| Mark confusion | telemetry marker; optional trainer note |

## Accessibility settings

```json
{
  "cue_density": "rich | standard | minimal",
  "practice_mode": true,
  "simulation_speed": 0.85,
  "threat_warning_distance": "short | medium | long",
  "scan_mode": "speech | tonal | both",
  "screen_reader_menu_text": true,
  "mono_fallback": false,
  "sudden_sound_reduction": true,
  "large_text_scale": 1.5,
  "high_contrast": true,
  "reduced_motion": true
}
```

## Menu rules

1. Every menu item can be reached with up/down or six-key equivalents.
2. Current menu item is announced by self-voice/TTS or screen-reader-compatible text.
3. Confirm and back always work.
4. No hover-only controls.
5. No icon-only controls without text labels.
6. Audio settings are reachable before gameplay.
7. TTS is interruptible by danger cues and menu confirmation.

## Menu state machine

```text
Boot
-> Main Menu
   -> Start Tutorial
   -> Start Game
   -> Research Mode
   -> Settings
   -> Sound Test
   -> Controls
   -> Quit
```

## First-launch script

On first launch, speak short instructions:

```text
Sound Maze. Use arrow keys or S D F J to move. Press K or Space to scan. Press Enter to start tutorial. Press Escape to go back.
```

Do not repeat this every launch unless the user chooses beginner mode.

## Tutorial modules

### Module 1 - Hear movement and walls

- Player moves in a straight corridor.
- Teach step/pellet tick and wall knock.
- No enemies.

Gate:

```text
player reaches end of corridor and correctly identifies wall feedback
```

### Module 2 - Turn at junctions

- Teach queued turns.
- Teach open-exit chimes.
- Player clears four-pellet loop.

Gate:

```text
player queues left/right at least twice without wall hit
```

### Module 3 - Scan mechanic

- Player enters junction.
- Press scan for compact summary: "up pellets, right wall, down safe, left fruit".
- Teach repeat-last-cue.

Gate:

```text
player uses scan, chooses pellet route, marks no confusion
```

### Module 4 - Enemy direction and escape

- One slow hunter enemy.
- Teach panned pulse and time-to-collision urgency.
- Teach panic reorient in practice mode.

Gate:

```text
player escapes enemy twice after warning cue
```

### Module 5 - Power mode

- Teach nearby power hum, activation, frightened enemy cue, countdown, expiration.

Gate:

```text
player activates power and hears countdown before expiration
```

### Module 6 - Real training level

- Combines movement, pellets, scan, enemy, and power.

Gate:

```text
player completes level or can explain death from replay summary
```

## Scan summaries

### Good live scan

```text
left fruit, up pellets, right enemy far, down wall
```

### Bad live scan

```text
There are multiple objects in the environment including a pellet line at tile coordinate...
```

## Panic reorient

In tutorial/practice mode:

1. Duck ambience.
2. Slow simulation to 40 percent for 2 seconds.
3. Speak compact state:

```text
safe now. facing right. left wall. up pellets. enemy far right.
```

In standard mode, panic gives only a short scan and marks telemetry.

## Trainer ethics in UI

The trainer panel must show coaching prompts:

- Ask first: "What did you hear?"
- Then guide: "Try scan if unsure."
- Do not show "solution route" by default.
- Show cue history so trainer understands the audio experience.

## Screen-reader strategy

- Menus expose text labels through SDL accessibility where available, plus self-voicing fallback.
- Live gameplay does not rely on external screen reader because real-time game cues are faster than speech.
- Results, settings, and research questionnaires can be read by screen reader and self-voicing.

## Acceptance tests

```text
TestAllMenusReachableKeyboardOnly
TestFirstLaunchCanStartTutorialWithoutMouse
TestSixKeyModeAllActionsMapped
TestScanSummaryUnderFiveSeconds
TestPanicReorientDoesNotHideDangerCue
TestSettingsAccessibleBeforeGameplay
TestTrainerHotkeysDoNotAffectPlayerInput
```

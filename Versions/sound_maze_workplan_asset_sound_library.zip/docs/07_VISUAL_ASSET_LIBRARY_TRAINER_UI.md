# 07 - Visual Asset Library, Low-Vision UI, and Trainer Dashboard

> Grounding: This package is built from the supplied Sound-Maze design plan, HCI study toolkit guide, and OpenAL Programmer's Guide. It keeps the project original: no copied Pac-Man art, sounds, level layouts, branding, or character names.

## Goal

Create an original visual layer for low-vision players, trainers, testers, and debugging. Visuals must support the sound-first product; they must never be required for core gameplay.

## Art direction

Working aesthetic: **high-contrast neon tactical map**.

- Player: `Echo Runner`, a circular waveform explorer.
- Collectibles: echo orbs.
- Power item: resonance core.
- Enemies: abstract sound-distortion creatures, not ghosts.
- Maze: clean geometric lab/sonar grid, not classic arcade maze art.

## Asset folder structure

```text
assetLibrary/
├── manifest.json
├── sprites/
│   ├── svg/
│   └── png/
├── tiles/
│   ├── svg/
│   └── png/
├── backgrounds/
│   └── svg/
├── ui/
│   └── svg/
└── atlases/
    ├── tile_atlas_32.png
    └── sprite_sheet_64.png
```

## Sprite list

| Asset ID | Size | Use | Notes |
|---|---:|---|---|
| `player_echo_runner` | 64x64 | player | circular waveform identity |
| `enemy_hunter` | 64x64 | direct pursuer | red angular distortion |
| `enemy_ambusher` | 64x64 | ambusher | purple sharp diamond |
| `enemy_trickster` | 64x64 | unpredictable enemy | green jitter form |
| `enemy_coward` | 64x64 | near/far switch enemy | blue hollow form |
| `pellet_echo_orb` | 32/64 | collectible | small bright dot |
| `power_resonance_core` | 64 | power | glowing ring |
| `fruit_signal_gem` | 64 | bonus | melodic lure visual |
| `life_token` | 32/64 | lives | small player icon |
| `scan_pulse` | 64 | scan overlay | expanding ring |

## Tile list

| Tile ID | Size | Use | Low-vision rule |
|---|---:|---|---|
| `tile_wall` | 32x32 | blocks movement | strong contrast border |
| `tile_corridor` | 32x32 | empty route | dark, quiet visual |
| `tile_pellet` | 32x32 | pellet path | dot plus corridor |
| `tile_junction` | 32x32 | decision tile | cross marker |
| `tile_power` | 32x32 | power item | ring marker |
| `tile_fruit_route` | 32x32 | bonus route | diamond marker |
| `tile_enemy_gate` | 32x32 | enemy home | striped hazard |
| `tile_safe_pocket` | 32x32 | recovery zone | soft square marker |
| `tile_warp` | 32x32 | shortcut | portal marker |
| `tile_unknown` | 32x32 | debug fallback | magenta/black warning |

## UI icons

| Icon ID | Use |
|---|---|
| `icon_scan` | scan button/settings |
| `icon_repeat` | repeat last cue |
| `icon_headphones` | headphone mode |
| `icon_mono` | mono fallback |
| `icon_keyboard` | controls |
| `icon_volume` | audio settings |
| `icon_danger` | threat panel |
| `icon_replay` | replay/export |
| `icon_research` | research mode |
| `icon_trainer` | trainer dashboard |

## Low-vision visual rules

1. Minimum contrast target: high contrast by default.
2. Support large UI scale: 1.0x, 1.25x, 1.5x, 2.0x.
3. Avoid tiny text in trainer view.
4. Use shape differences, not color only.
5. Offer reduced motion.
6. Show current audio cue as text in trainer dashboard.
7. Keep the player's audio experience complete without visual hints.

## Trainer dashboard layout

```text
+------------------------------------------------------------------+
| Sound Maze Trainer Dashboard                         Level 02    |
+---------------------------+--------------------------------------+
| Visual Maze Mirror        | Player State                         |
|                           | lives: 3                             |
|  grid + player + enemies  | score: 940                           |
|                           | mode: normal / power / paused        |
+---------------------------+--------------------------------------+
| Cue History               | Coaching Prompt                      |
| 12.4s enemy_near_amber R  | Ask: What do you hear?               |
| 13.0s junction_open_up    | Suggest: Press scan if unsure.       |
+---------------------------+--------------------------------------+
| Replay Markers            | Settings                             |
| confusion at 14.1s        | cue density: rich                    |
+------------------------------------------------------------------+
```

## Trainer panels

| Panel | Purpose | Must include |
|---|---|---|
| Maze mirror | visual debug/teaching | player, enemy, pellets, power, landmarks |
| Current cue | explain audio | cue ID, family, priority, relative direction |
| Cue history | coaching/debugging | last 20 cues with timestamps |
| Player state | quick overview | lives, score, mode, current direction |
| Threat model | fairness testing | route distance, TTC, red/amber/green |
| Replay markers | research | confusion, death, pauses, trainer notes |
| Help prompt | trainer ethics | ask-before-tell guidance |

## Asset loading strategy

`assetLibrary/manifest.json` maps IDs to paths. In production, copy to `assets/manifest.assets.json`.

```json
{
  "assets_version": "0.1.0",
  "sprites": [{"id":"player_echo_runner", "png":"sprites/png/player_echo_runner.png", "svg":"sprites/svg/player_echo_runner.svg"}]
}
```

## Animation plan

MVP can be static sprites. Later add:

- player pulse animation when moving;
- enemy vibration animation based on state;
- power ring expansion;
- scan pulse;
- pellet sparkle on collect;
- danger overlay in trainer view.

Keep animation optional for reduced-motion mode.

## Acceptance tests

```text
TestAllAssetManifestPathsExist
TestSpritesHaveTransparentBackground
TestTileAtlasLoads
TestTrainerViewCanRenderLevelWithoutGameplayAudio
TestHighContrastModeReadableAt1280x720
TestReducedMotionDisablesAnimations
```

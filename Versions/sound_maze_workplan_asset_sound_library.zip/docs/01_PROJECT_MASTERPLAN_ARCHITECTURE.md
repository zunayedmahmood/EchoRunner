# 01 - Project Masterplan and System Architecture

> Grounding: This package is built from the supplied Sound-Maze design plan, HCI study toolkit guide, and OpenAL Programmer's Guide. It keeps the project original: no copied Pac-Man art, sounds, level layouts, branding, or character names.

## Project name

Working title: **Sound Maze: Echo Runner**

Product type: blind-first real-time maze chase game for Windows, macOS, and Linux.

## Non-negotiable product doctrine

1. The game must be fully playable without sight.
2. Sound is the primary interface, not decoration.
3. Speech is for menus, tutorial, scan mode, trainer explanations, and post-event summaries - not for constant live narration.
4. Every death must be explainable from replay logs and cue history.
5. The trainer view is a teaching/debugging mirror. It must not become the real game.
6. The game must remain original in characters, sounds, level layouts, story, and branding.
7. Build research instrumentation from day one so blind-player testing is measurable, ethical, and repeatable.

## Core game loop

```text
listen to current state
-> choose direction / scan / queue turn
-> move through corridor
-> collect echoes/orbs
-> hear enemy pressure
-> use power state to reverse risk
-> clear level
-> review replay, score, and cue confusion
```

## User groups

### Primary

- Blind players using keyboard, headphones, or speakers.
- Low-vision players using high-contrast visuals and scalable UI.
- Trainers/teachers/researchers observing a visual mirror.

### Secondary

- Sighted players who want a sound-first challenge.
- HCI students running accessibility studies.
- Labs collecting structured usability and workload data.

## System architecture

```mermaid
flowchart TD
    Boot[Boot/Config Loader] --> Input[Input Runtime]
    Boot --> Assets[Asset Manifest Loader]
    Boot --> Audio[OpenAL Audio Engine]
    Boot --> UI[Menu + Trainer UI]
    Input --> Core[Game Core]
    Core --> Sim[Simulation Tick]
    Sim --> AI[Enemy AI Planner]
    Sim --> Rules[Collision/Scoring/Power Rules]
    Sim --> AudioMapper[Accessibility Runtime: State -> Cue Events]
    AudioMapper --> Audio
    AudioMapper --> Speech[Speech Queue]
    AudioMapper --> Telemetry[Telemetry + Replay Logger]
    Core --> Trainer[Trainer Visual Mirror]
    Trainer --> UI
    Telemetry --> Reports[Research Export: JSON/CSV/MD]
```

## Module boundaries

| Module | Owns | Must not own |
|---|---|---|
| `game_core` | grid, movement, score, lives, power, collision, deterministic state | audio playback, UI widgets, OS-specific code |
| `ai` | enemy state machine and target selection | direct audio mixing |
| `accessibility_runtime` | cue decisions, scan summaries, input remapping, cue density | physics or collision truth |
| `audio_openal` | OpenAL device/context, buffers, sources, priorities, gain, panning, attenuation | game rules |
| `presentation` | trainer UI, menu UI, low-vision visual rendering | critical gameplay state decisions |
| `telemetry` | input events, cue events, deaths, confusion markers, replay serialization | player-facing feedback |
| `research_mode` | participant/session IDs, consent, SUS/TLX prompts, anonymized exports | raw gameplay simulation |
| `platform` | file paths, audio library packaging, OS integration | gameplay logic |

## Recommended repository structure

```text
sound-maze/
├── CMakeLists.txt
├── CMakePresets.json
├── vcpkg.json
├── README.md
├── docs/
├── assets/
│   ├── sprites/
│   ├── tiles/
│   ├── backgrounds/
│   ├── ui/
│   └── manifest.assets.json
├── sounds/
│   ├── wav/
│   └── manifest.sounds.json
├── levels/
│   ├── level_01_training_loop.json
│   ├── level_02_crossroads.json
│   └── level_03_power_route.json
├── src/
│   ├── main.cpp
│   ├── core/
│   ├── ai/
│   ├── accessibility/
│   ├── audio/
│   ├── ui/
│   ├── telemetry/
│   ├── research/
│   └── platform/
├── tests/
│   ├── unit/
│   ├── integration/
│   ├── golden_replays/
│   └── accessibility_smoke/
├── scripts/
│   ├── dev_run.sh
│   ├── dev_run.ps1
│   ├── run_tests.sh
│   └── package_all.sh
└── exports/
    ├── replay_logs/
    ├── study_sessions/
    └── builds/
```

## Runtime data flow

```text
keyboard event
-> normalized input action
-> input buffer / direction queue
-> fixed timestep simulation
-> enemy AI state update
-> threat model update
-> cue event generation
-> OpenAL source update
-> trainer mirror update
-> telemetry write
```

## Fixed timestep decision

Use a deterministic fixed update step:

```text
simulation_tick_hz = 60
movement_tile_rate = level_config.player_tiles_per_second
audio_update_hz = 30 or every simulation tick for critical threats
trainer_ui_update_hz = 60 if possible, can degrade to 30
```

Reasons:

- Replay files become deterministic.
- Tests can validate exact state transitions.
- Cue timing can be measured.
- Input latency can be capped.

## State machines

### Game screen state

```text
boot -> main_menu -> tutorial_select -> tutorial_play
                      -> play -> pause -> results -> main_menu
                      -> settings -> main_menu
                      -> research_mode -> consent -> play -> questionnaire -> export
```

### Level state

```text
load -> ready_countdown -> active -> power_mode -> active -> cleared
                                      -> life_lost -> ready_countdown
                                      -> game_over -> results
```

### Enemy state

```text
scatter/patrol -> chase -> frightened -> return_home -> scatter/patrol
```

Every state transition must emit an audio transition cue and telemetry event.

## Data model

### Level file

```json
{
  "id": "level_01_training_loop",
  "name": "Training Loop",
  "tile_size_meters": 1.0,
  "cue_density_default": "rich",
  "grid": ["############", "#S..J....P#", "#..##..##.#", "#F.J...E..#", "############"],
  "legend": {"#":"wall", ".":"pellet", "S":"start", "J":"junction", "P":"power", "F":"fruit", "E":"enemy_gate"},
  "landmarks": [{"id":"fruit_corridor", "tiles":[[1,3],[2,3],[3,3]], "ambience":"landmark_fruit_corridor"}]
}
```

### Cue event

```json
{
  "time_ms": 18840,
  "cue_id": "enemy_near_hunter_red",
  "family": "danger",
  "priority": 90,
  "location_tile": [7, 3],
  "relative_direction": "right",
  "time_to_collision_ms": 1300,
  "interrupt_policy": "interrupt_lower_priority",
  "cooldown_ms": 250
}
```

### Replay event stream

```json
{
  "run_id": "RUN-2026-06-10-P01-001",
  "level_id": "level_01_training_loop",
  "seed": 120991,
  "events": [
    {"t": 0, "type": "level_start"},
    {"t": 810, "type": "input", "action": "move_right"},
    {"t": 820, "type": "cue", "cue_id": "turn_accepted_right"}
  ]
}
```

## Build phases

| Phase | Goal | Deliverable | Gate |
|---|---|---|---|
| M1 | deterministic grid movement | player moves, walls block, pellets collect | headless replay test passes |
| M2 | audio movement layer | pellet, wall, junction cues | complete training map with screen off |
| M3 | threat model + 1 enemy | hunter enemy + warning cue | avoid enemy in audio-only playtest |
| M4 | power mode | reversal and countdown | power never expires silently |
| M5 | tutorial + settings | keyboard-only onboarding | new player can start without mouse |
| M6 | trainer UI | visual mirror + cue history | trainer sees what player hears |
| M7 | research mode | telemetry, consent, SUS/TLX, exports | anonymized JSON/CSV/MD produced |
| M8 | packaging | Windows/macOS/Linux builds | clean install/run on each OS |

## Definition of fully working

The project is not finished when the visual prototype runs. It is finished when:

- A blind player can start tutorial, learn cues, and clear Level 1 without sighted control.
- All menus are keyboard-only and screen-reader-friendly.
- Direction queuing works at junctions.
- The audio engine uses priority, ducking, cooldown, and mono positional samples.
- Trainer dashboard shows maze, player state, enemy state, cue history, and coaching prompts.
- Telemetry can replay a run and explain deaths/confusions.
- Cross-OS build scripts work.
- Asset and sound manifests load all files without missing references.
- Research exports include raw telemetry, summaries, participant IDs, consent metadata, and anonymized output.

# 10 - Testing, QA, Research Protocol, and Run Commands

> Grounding: This package is built from the supplied Sound-Maze design plan, HCI study toolkit guide, and OpenAL Programmer's Guide. It keeps the project original: no copied Pac-Man art, sounds, level layouts, branding, or character names.

## Goal

Give the team a single implementation/testing checklist with exact commands, automated tests, manual accessibility tests, and HCI research workflow.

## Quick start commands

### Development run

```bash
./scripts/dev_run.sh
```

Equivalent direct command:

```bash
./build/dev-debug/sound-maze --level levels/level_01_training_loop.json --trainer --cue-density rich --telemetry
```

### Windows

```powershell
.\scripts\dev_run.ps1
```

### Sound test

```bash
./build/dev-debug/sound-maze --sound-test --sound-manifest sounds/manifest.sounds.json
```

### Headless replay test

```bash
./build/dev-debug/sound-maze --headless --level levels/level_01_training_loop.json --script tests/scripts/level01_clear.inputs --write-replay exports/replay_logs/level01.json
./build/dev-debug/sound-maze-tools replay-verify exports/replay_logs/level01.json --expect cleared=true --expect deaths=0
```

### Full automated test suite

```bash
cmake --preset dev-debug
cmake --build --preset dev-debug
ctest --preset dev-debug --output-on-failure
```

## Test pyramid

```text
Unit tests
  - scoring, movement, collision, AI, threat, cue decisions
Integration tests
  - level load, sound manifest, asset manifest, OpenAL smoke
Golden replay tests
  - deterministic playback of known input scripts
Accessibility smoke tests
  - keyboard-only menu, scan summaries, cue priority
Manual BLV playtests
  - tutorial, Level 1, settings, trainer ethics
```

## Automated test list

### Core simulation

```text
TestLevelParserRejectsUnknownTile
TestPlayerStopsAtWall
TestDirectionQueueExecutesAtJunction
TestDirectionQueueExpires
TestPelletCollectedOnce
TestPowerModeCountdownAndExpiry
TestLevelClearWhenRequiredPelletsCollected
TestReplayDeterministicWithSameSeed
```

### Accessibility runtime

```text
TestScanSummaryIncludesOpenDirections
TestScanSummaryOmitsIrrelevantDecorations
TestCuePriorityDangerOverReward
TestPanicReorientMarkedInTelemetry
TestMonoFallbackProvidesDirectionCodes
TestCueDensityMinimalReducesNoncriticalCues
```

### Audio/OpenAL

```text
TestOpenALDefaultDeviceInit
TestAllSoundManifestPathsExist
TestPositionalSoundsAreMono
TestSourcePoolStealsLowestPriority
TestCriticalCueInterruptsLowerPriority
TestListenerUpdatesFromPlayerPosition
```

### AI/fairness

```text
TestHunterTargetsPlayerTile
TestAmbusherTargetsProjectedTile
TestThreatUsesRouteDistance
TestDeathHasPreviousWarningCue
TestPowerCausesEnemyFrightenedState
TestEnemyStateTransitionHasCue
```

### Trainer/research

```text
TestTrainerReceivesCueHistory
TestTrainerHotkeysDoNotControlPlayer
TestResearchSessionCreatesParticipantFolder
TestConsentRequiredBeforeAudioRecording
TestAnonymizedExportRemovesRawIdentifiers
TestSummaryCsvContainsExpectedMetrics
```

## Manual QA script: screen-off internal test

1. Start tutorial with monitor turned away or window minimized.
2. Complete Module 1 using only keyboard and audio.
3. At every wall hit, ask: did the cue identify error without shame/frustration?
4. At every junction, press scan once, then choose a route.
5. Trigger enemy and verify red/amber/green urgency.
6. Activate power; verify activation, countdown, and expiration.
7. Clear level or explain death from replay.

Pass criteria:

- tester can complete Module 1-4 without visual information;
- no death happens without a warning cue;
- no menu requires mouse.

## Blind/low-vision research protocol

### Before session

- Explain project and consent.
- Confirm participant can stop anytime.
- Ask preferred audio output: headphones/speaker.
- Ask preferred input mode: arrow/WASD/six-key.
- Set volume safely.
- Assign anonymous ID, e.g. `P01`.

### Session tasks

1. Start tutorial without mouse.
2. Navigate corridor and hit wall intentionally.
3. Turn at two junctions.
4. Use scan to choose pellet route.
5. Escape one enemy.
6. Use power mode.
7. Clear training level or play 5 minutes.
8. Change an audio setting using keyboard.

### Data to collect

- Telemetry/replay.
- Cue confusion markers.
- Trainer notes.
- Task completion.
- Junction decision time.
- Death explanation.
- SUS and NASA-TLX after session.
- Short interview:
  - Which sounds were clear?
  - Which sounds were confusing?
  - Did any sound feel painful or tiring?
  - Did you feel in control?

## Research mode commands

```bash
sound-maze-tools study init accessibility_playtest_01 --lang en
sound-maze-tools participant add --study accessibility_playtest_01 --id P01 --input-mode six_key
sound-maze --research --study accessibility_playtest_01 --participant P01 --tutorial --telemetry
sound-maze-tools questionnaire sus --study accessibility_playtest_01 --participant P01 --lang en
sound-maze-tools questionnaire tlx --study accessibility_playtest_01 --participant P01 --lang en
sound-maze-tools export-summary exports/study_sessions/accessibility_playtest_01 --format csv,json,md
```

## Release gates

### MVP release gate

- Level 1 complete with audio-only internal test.
- Tutorial modules 1-4 complete.
- Sound test screen works.
- Trainer dashboard shows cue history.
- Telemetry replay generated.
- Windows/Linux dev builds verified.

### Alpha release gate

- Blind consultant walkthrough completed.
- At least 5 BLV playtest sessions.
- Players identify 80 percent of cue meanings after tutorial.
- Audio fatigue issues documented and addressed.
- Anonymized export verified.
- macOS build verified.

### Public release gate

- Installer/archive for Windows/macOS/Linux.
- Accessibility statement.
- Known limitations.
- Privacy statement.
- Third-party notices.
- No copyrighted maze-chase assets or sounds copied.

## Bug report template

```md
# Sound Maze bug report

- Build version:
- OS:
- Audio device:
- Input mode:
- Level:
- Cue density:
- Replay file:
- Expected:
- Actual:
- Did player understand what happened?: yes/no
- Related cue IDs:
- Screenshot/trainer view if available:
```

## Final command index

```bash
# configure
cmake --preset dev-debug

# build
cmake --build --preset dev-debug

# test
ctest --preset dev-debug --output-on-failure

# run game with trainer
./build/dev-debug/sound-maze --level levels/level_01_training_loop.json --trainer

# run sound test
./build/dev-debug/sound-maze --sound-test

# run headless deterministic replay
./build/dev-debug/sound-maze --headless --level levels/level_01_training_loop.json --script tests/scripts/level01_clear.inputs --write-replay exports/replay_logs/level01.json

# export research report
./build/dev-debug/sound-maze-tools export-summary exports/study_sessions/accessibility_playtest_01 --format csv,json,md
```

# 02 - Tech Stack, Repository Setup, and Coding Standards

> Grounding: This package is built from the supplied Sound-Maze design plan, HCI study toolkit guide, and OpenAL Programmer's Guide. It keeps the project original: no copied Pac-Man art, sounds, level layouts, branding, or character names.

## Recommended stack

### Core desktop game

| Layer | Choice | Reason |
|---|---|---|
| Language | C++20 | Native performance, OpenAL compatibility, cross-OS packaging |
| Build | CMake 3.25+ | Standard cross-platform build system |
| Dependencies | vcpkg manifest mode | Repeatable Windows/macOS/Linux dependency setup |
| Window/input | SDL2 or SDL3 | Keyboard, game loop, cross-OS windowing |
| Visual UI | Dear ImGui + SDL/OpenGL backend | Fast trainer dashboard and debug panels |
| Audio | OpenAL Soft | OpenAL-compatible 3D/spatial audio across OSes |
| Audio decode | dr_wav first; dr_mp3/stb_vorbis later | Simple static samples for MVP |
| JSON | nlohmann/json | Levels, manifests, telemetry, settings |
| Tests | Catch2 or GoogleTest | Unit/integration/golden replay tests |
| Formatting | clang-format | Consistent C++ style |
| Static analysis | clang-tidy where possible | Catch lifetime and API mistakes |
| Packaging | CPack + platform scripts | Installer/archive generation |

### Research/export helper

Use Python 3.11+ for optional offline analysis scripts:

```text
pandas       -> CSV summaries
jinja2       -> markdown report templates
matplotlib   -> optional plots
pytest       -> export script tests
```

Do not put core game runtime behind Python. Python is for tools, validation, and reports.

## Dependency policy

1. The game must run offline.
2. No cloud dependency in core gameplay.
3. Text-to-speech can have offline and online backends, but online TTS must be optional.
4. Use OpenAL Soft rather than vendor-specific OpenAL.
5. All third-party libraries must be listed in `THIRD_PARTY_NOTICES.md`.

## `vcpkg.json` example

```json
{
  "name": "sound-maze",
  "version-string": "0.1.0",
  "dependencies": [
    "sdl2",
    "openal-soft",
    "nlohmann-json",
    "imgui",
    "catch2"
  ]
}
```

## `CMakePresets.json` target presets

```json
{
  "version": 5,
  "configurePresets": [
    {
      "name": "dev-debug",
      "generator": "Ninja",
      "binaryDir": "build/dev-debug",
      "cacheVariables": {"CMAKE_BUILD_TYPE": "Debug"}
    },
    {
      "name": "release",
      "generator": "Ninja",
      "binaryDir": "build/release",
      "cacheVariables": {"CMAKE_BUILD_TYPE": "Release"}
    }
  ],
  "buildPresets": [
    {"name": "dev-debug", "configurePreset": "dev-debug"},
    {"name": "release", "configurePreset": "release"}
  ],
  "testPresets": [
    {"name": "dev-debug", "configurePreset": "dev-debug", "output": {"outputOnFailure": true}}
  ]
}
```

## Repository conventions

### Namespace layout

```cpp
namespace sm::core {}
namespace sm::ai {}
namespace sm::accessibility {}
namespace sm::audio {}
namespace sm::ui {}
namespace sm::telemetry {}
namespace sm::research {}
namespace sm::platform {}
```

### Error handling

- Core simulation functions should be deterministic and return typed results, not throw for ordinary game states.
- File loading can return `Expected<T, Error>` or a structured `LoadResult`.
- OpenAL calls must be wrapped by `checkAlError("context")` and `checkAlcError(device, "context")` in debug builds.
- The game must fail with a readable error if the audio device cannot initialize, then offer a no-audio debug mode only for developers.

## Coding rules

1. No gameplay decision inside UI draw code.
2. No audio playback inside enemy AI.
3. No direct file writes from simulation tick except telemetry buffering through a logger.
4. No hardcoded asset paths inside gameplay code; use manifests.
5. No stringly-typed tile logic after parsing; convert level chars into enum tiles.
6. Every cue has a unique stable ID.
7. Every accessibility setting has a default, saved value, and CLI override.
8. Every new level must have a blind-preview test.

## Core type sketch

```cpp
enum class TileType { Wall, Corridor, Pellet, Junction, Power, Fruit, EnemyGate, SafePocket, Warp };
enum class Direction { None, Up, Down, Left, Right };
enum class CueFamily { Critical, Danger, Navigation, Reward, Ambience, Speech };

struct TilePos { int x; int y; };

struct ActorState {
    TilePos tile;
    Direction dir;
    Direction queuedDir;
    float tileProgress;
    float speedTilesPerSec;
};

struct CueEvent {
    std::string cueId;
    CueFamily family;
    int priority;
    TilePos location;
    float gain;
    float pitch;
    int cooldownMs;
    bool interruptLowerPriority;
};
```

## Settings file

`config/settings.json`

```json
{
  "input_mode": "six_key",
  "audio": {
    "master_volume": 0.85,
    "effects_volume": 0.9,
    "speech_volume": 0.85,
    "ambience_volume": 0.35,
    "cue_density": "standard",
    "output_mode": "headphones",
    "mono_fallback": false,
    "sudden_sound_reduction": true
  },
  "accessibility": {
    "practice_mode": true,
    "scan_speech": true,
    "threat_warning_distance": "medium",
    "panic_slowdown_enabled": true,
    "large_text": true,
    "high_contrast": true
  },
  "research": {
    "telemetry_enabled": true,
    "anonymize_exports_by_default": true
  }
}
```

## First implementation sprint

### Day 1-2: skeleton

- Create repo and CMake project.
- Load `settings.json`.
- Open SDL window.
- Initialize OpenAL Soft.
- Load asset and sound manifests.
- Render trainer grid placeholder.

### Day 3-5: core simulation

- Level parser.
- Tile collision.
- Direction queuing.
- Pellet collection.
- Headless replay test.

### Day 6-8: audio cues

- Wall knock.
- Pellet tick.
- Junction chimes.
- Direction accepted click.
- Scan summary debug text.

### Day 9-12: enemies and threat

- Hunter enemy.
- Route distance/time-to-collision.
- Threat cue priority.
- Death explanation.

### Day 13-16: tutorial and settings

- Keyboard-only menu.
- Tutorial modules.
- Remapping screen.
- Audio settings screen.

### Day 17-21: trainer, telemetry, export

- Trainer dashboard.
- Cue history panel.
- Replay file.
- CSV/JSON/MD export.
- Release checklist.

## Definition of done for this file

- Project builds from clean clone.
- All assets and sounds load through manifests.
- First level can be run from CLI.
- Unit tests run in CI.
- No module imports from a forbidden layer.

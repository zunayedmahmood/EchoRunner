# 08 - Enemy AI, Fair Pressure, Telemetry, Replay, and Research Mode

> Grounding: This package is built from the supplied Sound-Maze design plan, HCI study toolkit guide, and OpenAL Programmer's Guide. It keeps the project original: no copied Pac-Man art, sounds, level layouts, branding, or character names.

## Goal

Build enemy pressure that is tense but fair, and make every important event reproducible through telemetry and replay.

## Enemy archetypes

| Archetype | Behavior | Sound identity | Fairness rule |
|---|---|---|---|
| Hunter | targets player's current tile | low pulse | never spawn silently nearby |
| Ambusher | targets projected future tile | sharp syncopation | teach before using in real levels |
| Trickster | blends chase and random legal turns | jitter motif | randomness uses fixed seed for replay |
| Coward | chases far, retreats near | hollow low-high | state change has cue |

## Enemy state machine

```text
scatter/patrol -> chase -> frightened -> return_home -> scatter/patrol
```

Each state has:

- speed multiplier;
- target rule;
- allowed turns;
- audio signature;
- cue priority modifier.

## Pathfinding

MVP:

- Use BFS/A* on tile graph.
- Avoid immediate reversal unless state forces it.
- Every enemy updates target at tile centers, not every pixel.
- Use deterministic random seed for all non-deterministic choices.

## Threat model

Threat should use route topology and time-to-collision, not raw Euclidean distance.

```cpp
ThreatLevel computeThreat(const Enemy& e, const Player& p, const LevelGraph& graph) {
    int routeDist = graph.shortestPathTiles(e.tile, p.tile);
    bool sameCorridor = graph.sameCorridorLineOfSight(e.tile, p.tile);
    bool intercepting = predictsIntercept(e, p, graph);
    float ttc = routeDist / std::max(0.1f, e.speedTilesPerSec);

    if (sameCorridor && intercepting && ttc < 1.2f) return ThreatLevel::Red;
    if (intercepting && ttc < 3.0f) return ThreatLevel::Amber;
    if (routeDist < warningTiles) return ThreatLevel::Green;
    return ThreatLevel::Silent;
}
```

## Multi-enemy audio rule

Never play four full enemy cues at full priority.

- Full cue for highest threat.
- Reduced/light cue for second threat.
- Remaining enemies appear in scan summary/trainer view.
- In power mode, enemy frightened cues can be lighter unless close.

## Fairness gates

A threat is unfair if:

- red danger starts less than 500 ms before unavoidable collision;
- enemy state changes without cue;
- power expires without countdown;
- two enemies produce indistinguishable cues;
- player death explanation cannot identify cause;
- replay cannot reproduce the death.

## Telemetry event types

```json
{
  "event_types": [
    "run_start", "run_end", "level_start", "level_clear", "life_lost",
    "input", "turn_queued", "turn_executed", "wall_hit",
    "pellet_collected", "fruit_spawned", "fruit_collected",
    "power_near", "power_activate", "power_countdown", "power_expire",
    "enemy_state_change", "threat_change", "cue_start", "cue_stop",
    "scan_requested", "scan_summary", "panic_reorient",
    "pause", "resume", "confusion_marker", "trainer_note"
  ]
}
```

## Replay file structure

```json
{
  "schema_version": "0.1.0",
  "game_version": "0.1.0",
  "run_id": "RUN-P01-001",
  "participant_id": "P01",
  "level_id": "level_01_training_loop",
  "rng_seed": 12345,
  "settings_snapshot": {"cue_density":"rich", "input_mode":"six_key"},
  "events": [
    {"t_ms":0, "type":"run_start"},
    {"t_ms":820, "type":"input", "action":"MoveRight"},
    {"t_ms":900, "type":"cue_start", "cue_id":"pellet_tick"}
  ],
  "summary": {"cleared":true, "deaths":0, "score":940, "confusion_markers":1}
}
```

## Research mode integration

Borrow the HCI toolkit's local-first research workflow:

```text
create study
-> add participant ID
-> confirm consent
-> run tutorial/game tasks
-> collect telemetry and notes
-> run SUS/NASA-TLX or custom short forms
-> export anonymized data
```

## Participant/session policy

- Default participant IDs: `P01`, `P02`, etc.
- Never require real names.
- Store consent metadata, not legal personal details.
- Audio recording must require explicit consent.
- Anonymized export should remove free-text identifiers and raw audio by default.

## Research export folder

```text
exports/study_sessions/accessibility_playtest_01/
├── study.json
├── participants.csv
├── runs/
│   ├── P01_run_001.replay.json
│   └── P02_run_001.replay.json
├── questionnaires/
│   ├── P01_sus.json
│   └── P01_nasa_tlx.json
├── notes/
│   └── P01_notes.md
├── summary.csv
└── report.md
```

## Metrics to calculate

| Metric | Source | Why it matters |
|---|---|---|
| first-turn success | tutorial telemetry | basic movement clarity |
| junction decision time | input + position | cognitive load at choices |
| avoidable deaths | replay review | fairness of threat cues |
| cue confusion count | marker + interview | sound grammar quality |
| scan frequency | scan events | player confidence/cognitive load |
| panic use | panic events | recovery need |
| pause frequency | pause events | fatigue/stress |
| level clear rate | run summary | playability |
| SUS | questionnaire | perceived usability |
| NASA-TLX | questionnaire | workload/fatigue |

## Study tasks

1. Navigate a straight corridor and stop at a wall.
2. Choose route with more pellets at a junction.
3. Identify enemy direction and escape.
4. Use power mode and chase/avoid enemy.
5. Clear Level 1 without trainer instruction.
6. Change audio settings using only keyboard.

## Automated fairness tests

```text
TestEveryDeathHasPriorThreatCue
TestThreatCueUsesRouteDistanceNotEuclideanOnly
TestEnemyStateChangeEmitsCue
TestMultipleEnemiesMixOnlyTopTwoThreats
TestReplayRecreatesEnemyPositions
TestPowerExpirationHasCountdownCue
TestScanSummaryMatchesWorldState
```

## Manual release gates

- At least one blind consultant walkthrough before public release.
- 5-player blind/low-vision usability test before claiming accessibility quality.
- Players can explain at least 80 percent of cue meanings after tutorial.
- Most early-level deaths are understood as fair.
- Trainer prompts guide without taking over.

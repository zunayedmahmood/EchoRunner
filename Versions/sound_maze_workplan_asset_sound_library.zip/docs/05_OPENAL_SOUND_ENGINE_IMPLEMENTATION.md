# 05 - OpenAL Sound Engine Implementation

> Grounding: This package is built from the supplied Sound-Maze design plan, HCI study toolkit guide, and OpenAL Programmer's Guide. It keeps the project original: no copied Pac-Man art, sounds, level layouts, branding, or character names.

## Goal

Implement a robust OpenAL Soft audio layer that translates game cue events into spatial, prioritized, fatigue-aware sound.

## OpenAL mental model

OpenAL uses:

- **Device**: the output audio device.
- **Context**: the active OpenAL state container.
- **Listener**: the player/hearing position. There is one listener per context.
- **Buffer**: loaded PCM audio data.
- **Source**: a playable positioned sound object with gain, pitch, looping, position, velocity, and attached buffer.

## Key implementation rule

Use **mono WAV samples** for any positional cue. OpenAL does not spatialize multi-channel buffers the same way; keep stereo only for non-positional music/menus if you add them later.

## Audio coordinate system

Use a 2D grid mapped into 3D OpenAL coordinates:

```text
level tile (x, y)
-> OpenAL position (x * meters_per_tile, 0.0, -y * meters_per_tile)
```

Listener:

```text
position = player tile/interpolated position
orientation.at = vector of player's facing direction
orientation.up = (0, 1, 0)
```

Direction mapping:

| Game direction | OpenAL vector |
|---|---|
| up/north | (0, 0, -1) |
| down/south | (0, 0, 1) |
| left/west | (-1, 0, 0) |
| right/east | (1, 0, 0) |

## Initialization sequence

```cpp
class OpenALDevice {
public:
    void init() {
        device_ = alcOpenDevice(nullptr); // default device
        if (!device_) throw AudioError("Failed to open OpenAL device");

        context_ = alcCreateContext(device_, nullptr);
        if (!context_) throw AudioError("Failed to create OpenAL context");

        if (!alcMakeContextCurrent(context_))
            throw AudioError("Failed to make OpenAL context current");

        alDistanceModel(AL_INVERSE_DISTANCE_CLAMPED);
        alDopplerFactor(0.0f); // MVP: avoid confusing pitch shift unless intentionally designed
    }

    ~OpenALDevice() { shutdown(); }

    void shutdown() {
        if (context_) {
            alcMakeContextCurrent(nullptr);
            alcDestroyContext(context_);
            context_ = nullptr;
        }
        if (device_) {
            alcCloseDevice(device_);
            device_ = nullptr;
        }
    }
private:
    ALCdevice* device_ = nullptr;
    ALCcontext* context_ = nullptr;
};
```

## Device enumeration

Settings screen should expose available devices when the enumeration extension is available:

```cpp
const ALCchar* devices = alcGetString(nullptr, ALC_DEVICE_SPECIFIER);
const ALCchar* defaultDevice = alcGetString(nullptr, ALC_DEFAULT_DEVICE_SPECIFIER);
```

Offer default first. If enumeration fails, still use default device.

## Buffer loading

MVP: use `.wav` and `dr_wav`.

```cpp
struct AudioBuffer {
    ALuint id;
    std::string cueId;
    int sampleRate;
    int channels;
    float durationSec;
};
```

Load rules:

- Validate file exists.
- Decode to PCM16.
- Reject positional sounds if `channels != 1`.
- Call `alGenBuffers`.
- Fill using `alBufferData`.
- Store by `cue_id`.

## Source pool

Do not allocate sources per cue in real time. Create pools:

| Pool | Count | Use |
|---|---:|---|
| critical | 4 | life lost, collision, red threat |
| danger | 8 | enemies, countdown |
| navigation | 8 | junctions, wall, scan tonal cues |
| reward | 8 | pellets, fruit, combo |
| ambience | 4 | zone landmarks |
| speech | 2 | TTS/static prompts |

When source count is exhausted, steal lowest-priority source whose cue is interruptible.

## Cue event handling

```cpp
void AudioEngine::playCue(const CueEvent& cue) {
    if (cooldowns_.active(cue.cueId)) return;

    SourceHandle source = sourcePool_.acquire(cue.priority, cue.interruptPolicy);
    if (!source.valid()) return;

    ALuint buffer = buffers_.at(cue.assetId).id;
    alSourcei(source.id, AL_BUFFER, buffer);
    alSourcef(source.id, AL_GAIN, cue.gain * volumeFor(cue.family));
    alSourcef(source.id, AL_PITCH, cue.pitch);
    alSource3f(source.id, AL_POSITION, cue.worldX, cue.worldY, cue.worldZ);
    alSourcei(source.id, AL_LOOPING, cue.loop ? AL_TRUE : AL_FALSE);
    alSourcePlay(source.id);

    cooldowns_.start(cue.cueId, cue.cooldownMs);
    telemetry_.recordCueStarted(cue);
}
```

## Priority and ducking

Priority order:

```text
critical > danger > navigation > reward > ambience
```

Ducking rules:

- Critical cues mute or strongly duck ambience/reward.
- Red danger cues duck reward and ambience.
- Navigation cues may duck ambience only.
- Reward cues never interrupt danger.
- Speech is cancellable by danger.

## Distance model

Use:

```cpp
alDistanceModel(AL_INVERSE_DISTANCE_CLAMPED);
```

Recommended source settings:

```cpp
alSourcef(source, AL_REFERENCE_DISTANCE, 1.0f);  // one tile
alSourcef(source, AL_MAX_DISTANCE, 8.0f);        // beyond 8 tiles fades/min gain
alSourcef(source, AL_ROLLOFF_FACTOR, 1.2f);
alSourcef(source, AL_MIN_GAIN, 0.05f);
alSourcef(source, AL_MAX_GAIN, 1.0f);
```

For UI/menu cues:

```cpp
alSourcei(source, AL_SOURCE_RELATIVE, AL_TRUE);
alSource3f(source, AL_POSITION, 0, 0, 0);
```

## Stereo, mono, and accessibility fallback

### Headphone/stereo mode

- Use OpenAL spatialization.
- Place enemies and fruit in world coordinates.
- Use relative cue positions for left/right/up/down chimes.

### Mono fallback

When `mono_fallback = true`:

- Do not rely on panning.
- Use direction-coded timbres/pitches:
  - left = lower two-note motif
  - right = higher two-note motif
  - up = rising gliss
  - down = falling gliss
- Speech scan can add direction labels.

## Streaming sounds

For MVP, avoid streaming except long ambience/music. If streaming is needed, use OpenAL queued buffers:

```text
alSourceQueueBuffers -> alSourcePlay -> alSourceUnqueueBuffers processed -> refill -> requeue
```

All queued buffers on one streaming source should use the same format.

## Error checking

```cpp
void checkAl(const char* label) {
    ALenum err = alGetError();
    if (err != AL_NO_ERROR) {
        throw AudioError(std::string(label) + ": OpenAL error " + std::to_string(err));
    }
}
```

Call after init, buffer load, source allocation, play/stop, listener update.

## Sound test screen

Create a menu item "Sound Test" that lets players test:

- left/right/up/down cues;
- enemy near red/amber/green;
- power activation/countdown/expiration;
- fruit lure;
- wall knock;
- mono fallback;
- volume sliders.

## Acceptance tests

```text
TestOpenALInitDefaultDevice
TestAllManifestSoundsLoad
TestPositionalSoundsAreMono
TestCriticalCueInterruptsReward
TestRewardDoesNotInterruptDanger
TestSourcePoolDoesNotAllocateInTick
TestListenerFollowsPlayer
TestMonoFallbackUsesDirectionCodes
```

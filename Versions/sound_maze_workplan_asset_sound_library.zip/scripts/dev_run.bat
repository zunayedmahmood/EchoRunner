@echo off
build\dev-debug\sound-maze.exe --level levels\level_01_training_loop.json --trainer --cue-density rich --telemetry %*

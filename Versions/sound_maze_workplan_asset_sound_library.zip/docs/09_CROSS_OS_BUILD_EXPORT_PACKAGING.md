# 09 - Cross-OS Support, Build, Export, and Packaging

> Grounding: This package is built from the supplied Sound-Maze design plan, HCI study toolkit guide, and OpenAL Programmer's Guide. It keeps the project original: no copied Pac-Man art, sounds, level layouts, branding, or character names.

## Goal

Make the game build and run consistently on Windows, macOS, and Linux, including OpenAL Soft runtime packaging and local-first export folders.

## Supported OS targets

| OS | Minimum | Build route | Package |
|---|---|---|---|
| Windows | Windows 10/11 64-bit | MSVC + CMake + vcpkg | `.zip` and later installer |
| macOS | macOS 12+ | clang + CMake + vcpkg/homebrew | `.app` bundle + `.dmg` later |
| Linux | Ubuntu 22.04+ equivalent | gcc/clang + CMake | `.tar.gz`, AppImage later |

## Runtime dependencies

- SDL2 dynamic library.
- OpenAL Soft dynamic library.
- C++ runtime if required.
- Assets, sounds, levels, config defaults.
- Optional TTS engine dependencies depending on backend.

## Folder layout after install

```text
SoundMaze/
├── sound-maze.exe / sound-maze
├── assets/
├── sounds/
├── levels/
├── config/
│   └── defaults.json
├── docs/
├── licenses/
└── tools/
```

User writable data should not be placed beside executable on macOS/Linux. Use platform paths:

| Data | Windows | macOS | Linux |
|---|---|---|---|
| settings | `%APPDATA%/SoundMaze/settings.json` | `~/Library/Application Support/SoundMaze/settings.json` | `~/.config/sound-maze/settings.json` |
| exports | `%USERPROFILE%/Documents/SoundMaze/exports` | `~/Documents/SoundMaze/exports` | `~/Documents/SoundMaze/exports` |
| logs | `%LOCALAPPDATA%/SoundMaze/logs` | `~/Library/Logs/SoundMaze` | `~/.local/state/sound-maze/logs` |

## OpenAL Soft packaging

### Windows

Bundle:

```text
OpenAL32.dll
soft_oal.dll if applicable
```

Place DLLs beside the executable. Add a startup check that prints the selected OpenAL device.

### macOS

Options:

- Link via Homebrew for development.
- Bundle `.dylib` inside `.app/Contents/Frameworks` for release.
- Fix rpaths using `install_name_tool`.

### Linux

Options:

- Use system `libopenal.so` for dev.
- Bundle with AppImage for release.
- For `.tar.gz`, document package install:

```bash
sudo apt install libopenal1 libsdl2-2.0-0
```

## Build commands

### Windows PowerShell

```powershell
git clone <repo-url> sound-maze
cd sound-maze
vcpkg install --triplet x64-windows
cmake --preset dev-debug
cmake --build --preset dev-debug
ctest --preset dev-debug
.uild\dev-debug\sound-maze.exe --level levels\level_01_training_loop.json --trainer
```

### macOS

```bash
brew install cmake ninja openal-soft sdl2
cmake --preset dev-debug
cmake --build --preset dev-debug
ctest --preset dev-debug
./build/dev-debug/sound-maze --level levels/level_01_training_loop.json --trainer
```

### Linux

```bash
sudo apt update
sudo apt install -y build-essential cmake ninja-build libsdl2-dev libopenal-dev
cmake --preset dev-debug
cmake --build --preset dev-debug
ctest --preset dev-debug
./build/dev-debug/sound-maze --level levels/level_01_training_loop.json --trainer
```

## CLI runtime flags

```bash
sound-maze   --level levels/level_01_training_loop.json   --input-mode six_key   --cue-density rich   --trainer   --telemetry   --export-dir exports/dev_run
```

Headless:

```bash
sound-maze --headless --level levels/level_01_training_loop.json --script tests/scripts/level01_clear.inputs --write-replay exports/replay_logs/level01.json
```

Sound test:

```bash
sound-maze --sound-test --sound-manifest sounds/manifest.sounds.json
```

Research mode:

```bash
sound-maze --research --study accessibility_playtest_01 --participant P01 --level levels/level_01_training_loop.json
```

## Export commands

```bash
sound-maze-tools export-summary exports/study_sessions/accessibility_playtest_01 --format csv,json,md
sound-maze-tools anonymize exports/study_sessions/accessibility_playtest_01 --remove-audio --out exports/anonymized/accessibility_playtest_01
sound-maze-tools replay-inspect exports/replay_logs/P01_run_001.replay.json
```

## Packaging checklist

- All manifest paths use relative paths.
- All assets/sounds included.
- App starts offline.
- Audio device fallback works.
- Settings folder is writable.
- Exports folder is writable.
- License notices included.
- No debug-only absolute paths.
- No real participant data in sample package.
- `--sound-test` works after install.
- Tutorial starts with keyboard only.

## CI matrix

```yaml
strategy:
  matrix:
    os: [windows-latest, macos-latest, ubuntu-latest]
    build_type: [Debug, Release]
```

Run in CI:

```text
configure
build
unit tests
headless replay tests
manifest path test
package smoke test
```

## Release versioning

Use semantic versioning:

```text
0.1.0 internal prototype
0.2.0 first audio-only playable
0.3.0 trainer + research mode
0.5.0 blind consultant tested alpha
1.0.0 public release after BLV testing gates
```

## Acceptance gate

A release build is accepted only when:

- clean install works on all 3 OS targets;
- first launch creates settings folder;
- all levels/assets/sounds load;
- OpenAL device initializes or fails gracefully;
- exported replay/report can be opened outside the game;
- no participant data is uploaded by default.

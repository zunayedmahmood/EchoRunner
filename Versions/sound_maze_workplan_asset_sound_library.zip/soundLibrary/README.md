# Sound Library

Original synthesized placeholder sound cues for Sound Maze: Echo Runner.

- All WAVs are mono PCM16 at 44.1 kHz for OpenAL positional compatibility.
- Use `manifest.json` as the loading contract.
- Replace sounds later with professional audio while preserving cue IDs.
- Critical cues must keep priority and interrupt behavior.

Run a sound test inside the game before playtesting with blind/low-vision participants.

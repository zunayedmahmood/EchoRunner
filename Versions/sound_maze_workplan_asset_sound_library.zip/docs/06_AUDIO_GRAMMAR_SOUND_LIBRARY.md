# 06 - Audio Grammar and Sound Library Specification

> Grounding: This package is built from the supplied Sound-Maze design plan, HCI study toolkit guide, and OpenAL Programmer's Guide. It keeps the project original: no copied Pac-Man art, sounds, level layouts, branding, or character names.

## Goal

Define every sound the game needs and how each sound maps to a player decision. This file works with the generated `soundLibrary/` folder.

## Audio design principles

1. Each sound family must be instantly distinguishable.
2. Critical danger must never be hidden under reward or ambience.
3. Use event cues more than continuous noise.
4. Use short speech only when it beats tonal cues.
5. Give every cue a stable ID for telemetry.
6. Design for headphone spatialization and mono fallback.

## Cue families

| Family | Timbre | Pitch/rhythm | Spatial behavior | Example |
|---|---|---|---|---|
| Danger | low pulse, rough tone, urgent click | faster as time-to-collision shrinks | world positioned | enemy near |
| Navigation | clean chimes, knocks, compass pings | short motifs | relative left/right/up/down | junction open |
| Reward | bright ticks and soft melodies | rhythmic, light | usually centered or route-local | pellet, fruit |
| Power | bass swell -> bright transformation | countdown ticks | centered + enemy state change | power active |
| Ambience | subtle texture | slow loop | zone-local, low priority | fruit corridor |
| Speech | TTS/static voice | short | non-positional | menu/status |

## Critical mix order

```text
1. collision / death / red threat
2. enemy near / power countdown
3. junction / route / wall feedback
4. pellet / fruit / score
5. ambience / music
```

## Sound library manifest fields

Each sound entry should define:

```json
{
  "cue_id": "enemy_hunter_near_red",
  "file": "wav/enemy_hunter_near_red.wav",
  "family": "danger",
  "priority": 90,
  "positional": true,
  "loop": false,
  "cooldown_ms": 180,
  "default_gain": 0.85,
  "mono_required": true,
  "interrupt_policy": "interrupt_lower_priority",
  "decision_answered": "How urgent is danger and from where?"
}
```

## Required sound list

### Movement and navigation

| Cue ID | Use | Priority | Notes |
|---|---|---:|---|
| `move_step_soft` | optional movement tick | 20 | reduce in expert mode |
| `wall_knock` | invalid turn/hit wall | 55 | dry, short, non-punishing |
| `turn_accepted_left` | queued left accepted | 45 | tiny left-coded click |
| `turn_accepted_right` | queued right accepted | 45 | tiny right-coded click |
| `turn_accepted_up` | queued up accepted | 45 | rising click |
| `turn_accepted_down` | queued down accepted | 45 | falling click |
| `junction_open_left` | left exit available | 50 | relative direction cue |
| `junction_open_right` | right exit available | 50 | relative direction cue |
| `junction_open_up` | up exit available | 50 | relative direction cue |
| `junction_open_down` | down exit available | 50 | relative direction cue |
| `scan_start` | scan requested | 35 | short neutral pulse |
| `scan_success` | scan response available | 35 | precedes speech summary |
| `panic_reorient` | panic key accepted | 75 | calming but noticeable |

### Reward

| Cue ID | Use | Priority | Notes |
|---|---|---:|---|
| `pellet_tick` | collect pellet | 25 | bright, short |
| `pellet_row_clear` | clear route segment | 35 | pitch rise |
| `fruit_lure` | fruit/bonus direction | 40 | melodic, lure-like |
| `fruit_collect` | bonus collected | 45 | confirmation flourish |
| `combo_tick` | enemy/power combo | 45 | optional |
| `level_clear` | level completed | 60 | celebration cadence |

### Danger/enemy

| Cue ID | Use | Priority | Notes |
|---|---|---:|---|
| `enemy_hunter_loop` | hunter identity | 70 | low pulse |
| `enemy_ambusher_loop` | ambusher identity | 70 | sharp syncopated tone |
| `enemy_trickster_loop` | unpredictable enemy | 68 | jitter motif |
| `enemy_coward_loop` | near/far switch enemy | 65 | hollow low-high |
| `enemy_near_green` | safe awareness | 60 | light cue only |
| `enemy_near_amber` | potential intercept | 80 | urgent pulse |
| `enemy_near_red` | collision likely | 95 | can interrupt almost everything |
| `collision_warning` | immediate collision | 100 | critical |
| `life_lost` | death/life lost | 100 | followed by explanation in tutorial |

### Power mode

| Cue ID | Use | Priority | Notes |
|---|---|---:|---|
| `power_near` | power item nearby | 50 | warm hum |
| `power_activate` | mode begins | 90 | obvious transformation |
| `enemy_frightened` | enemy vulnerable | 80 | enemy timbre flips |
| `power_countdown` | expiring soon | 95 | never suppress |
| `power_expire` | danger returns | 95 | clear transition |

### Ambience and landmarks

| Cue ID | Use | Priority | Notes |
|---|---|---:|---|
| `landmark_safe_loop` | safe/reorientation zone | 15 | low calm wind |
| `landmark_enemy_gate` | enemy home area | 15 | low machine hum |
| `landmark_fruit_corridor` | bonus route | 15 | soft marimba-like motif |
| `warp_enter` | enter shortcut | 55 | transition sound |
| `warp_exit` | exit shortcut | 55 | exit confirmation |

### UI/trainer/research

| Cue ID | Use | Priority | Notes |
|---|---|---:|---|
| `menu_move` | menu item changed | 25 | simple tick |
| `menu_confirm` | menu selected | 35 | confirmation |
| `menu_back` | back/cancel | 35 | descending cue |
| `settings_changed` | setting toggled | 35 | confirmation |
| `trainer_marker` | trainer/confusion marker | 30 | quiet |
| `tutorial_prompt` | tutorial step starts | 40 | precedes speech |
| `questionnaire_prompt` | research prompt | 40 | non-gameplay |

## Speech line rules

Keep lines short. Examples:

```text
"left fruit, up pellets, right enemy far, down wall"
"power ending"
"enemy right"
"safe now, facing up"
"level clear, score 940"
```

## Dynamic cue parameters

### Threat urgency

```text
if time_to_collision < 1.2s: red
else if time_to_collision < 3.0s: amber
else if route_distance < warning_distance: green
else no cue
```

Map urgency to:

- higher pulse rate;
- slightly higher gain, capped;
- reduced cooldown;
- higher priority.

### Pellet progress

- Single pellet: soft tick.
- Row/route segment clear: short rising phrase.
- Last 10 percent of pellets: occasional progress cue, not constant speech.

## Avoiding fatigue

Settings must control:

- master/effects/speech/ambience volume;
- cue density;
- threat warning distance;
- sudden sound reduction;
- low-frequency reduction;
- speech speed;
- mono/headphone mode.

## Generated files in this package

The included `soundLibrary/wav/` files are simple synthesized placeholder WAVs for implementation and testing. They are original and safe to replace later with professional audio. Keep the same cue IDs and update the manifest.

## Sound acceptance checklist

- Positional cues are mono.
- No sound clips on playback.
- Critical cues are clearly louder/clearer but not painful.
- Enemy personalities sound distinct.
- Power mode activation, countdown, and expiration are impossible to miss.
- Audio-only playtesters can identify at least 80 percent of cue meanings after tutorial.

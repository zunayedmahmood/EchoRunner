#!/usr/bin/env bash
set -euo pipefail
cmake --preset dev-debug
cmake --build --preset dev-debug
ctest --preset dev-debug --output-on-failure
